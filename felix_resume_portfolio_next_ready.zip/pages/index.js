import ResumePortfolio from '@/components/ResumePortfolio'

export default function Home() {
  return <ResumePortfolio />
}
